
local X = 0
local cam = getRoom().Camera
function onBegin()
    cam.Zoom = 0.25
    disableMovement()
    moveCam()
    enableMovement()
end
function onStay(player)
    cam.Y = 195
    cam.X = X
end
function moveCam()
    for i=0,7778880,1168 do
        X = i
        wait(0.016666666666666666)
    end
end
    